ace.require(["ace/snippets/jade"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
