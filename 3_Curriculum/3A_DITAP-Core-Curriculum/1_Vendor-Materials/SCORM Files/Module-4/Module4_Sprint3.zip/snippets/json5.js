ace.require(["ace/snippets/json5"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
