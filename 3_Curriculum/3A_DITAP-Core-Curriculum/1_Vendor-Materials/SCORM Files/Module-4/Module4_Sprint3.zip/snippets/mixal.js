ace.require(["ace/snippets/mixal"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
