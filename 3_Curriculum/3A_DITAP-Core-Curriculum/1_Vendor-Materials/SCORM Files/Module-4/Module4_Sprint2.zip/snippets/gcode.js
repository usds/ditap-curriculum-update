ace.require(["ace/snippets/gcode"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
