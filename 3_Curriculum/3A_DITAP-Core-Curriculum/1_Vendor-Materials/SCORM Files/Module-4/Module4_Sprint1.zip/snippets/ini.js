ace.require(["ace/snippets/ini"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
