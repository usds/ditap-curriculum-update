ace.require(["ace/snippets/xml"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
