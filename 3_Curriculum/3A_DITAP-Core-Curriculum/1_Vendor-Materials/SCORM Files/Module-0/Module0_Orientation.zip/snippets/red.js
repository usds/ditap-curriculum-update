ace.require(["ace/snippets/red"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
