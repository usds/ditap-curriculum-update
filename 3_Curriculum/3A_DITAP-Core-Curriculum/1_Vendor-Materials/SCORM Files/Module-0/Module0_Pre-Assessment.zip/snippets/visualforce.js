ace.require(["ace/snippets/visualforce"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
