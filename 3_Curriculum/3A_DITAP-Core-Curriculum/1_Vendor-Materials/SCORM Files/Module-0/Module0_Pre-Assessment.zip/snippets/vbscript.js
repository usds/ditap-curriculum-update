ace.require(["ace/snippets/vbscript"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
