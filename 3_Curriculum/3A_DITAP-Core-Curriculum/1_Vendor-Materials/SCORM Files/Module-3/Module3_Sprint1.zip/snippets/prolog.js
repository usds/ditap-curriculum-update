ace.require(["ace/snippets/prolog"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
