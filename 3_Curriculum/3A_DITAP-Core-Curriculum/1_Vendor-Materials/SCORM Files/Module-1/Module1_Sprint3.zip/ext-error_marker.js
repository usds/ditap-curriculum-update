ace.require(["ace/ext/error_marker"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
