ace.require(["ace/snippets/twig"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
